
<?php session_start(); ?>
<?php
if (!isset($_SESSION["username"])) {
  header("Location: ../php_users_profile/login.php");
  exit;
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Travel Destinations</title>
  <link rel="stylesheet" href="../css/gallery.css" />
  <link rel="stylesheet" href="../css/profile.css" />
  <link rel="stylesheet" href="../css/logo_php.css" />
  <link rel="icon" href="../images/logo_image_1.jpg" type="image/jpg">
</head>
<body>

<header>
  <div class="container">
    <a href="home.html" class="logo"><img src="../images/logo_image_1.jpg" alt="Tour Starter Logo" class="logo-img">TOUR STARTER</a>
    <nav>
      <ul>
        <li><a href="home.php">Home</a></li>
        <li><a href="Gallery.php">Gallery</a></li>
        <li><a href="about.php">About</a></li>
        <li><a href="contact.php">Contact</a></li>
        <?php if (isset($_SESSION["username"])): ?>
            <li class="profile-img-li">
                <a href="../php_users_profile/profile.php" class="profile-link">
                    <img src="../profile_images/<?php echo $_SESSION['profile_image']; ?>" alt="User Profile Image" class="profile-img-corner">
                </a>
            </li>
          <?php endif; ?>
      </ul>
    </nav>
  </div>
</header>

<main>
  <div class="text-center">
    <h1>Explore Amazing Destinations</h1>
    <p>Discover breathtaking landscapes and unforgettable experiences around the world.</p>
  </div>

  <div class="grid">

    <div class="card">
      <img src="../images/img_1.jpg" alt="Canadian Rockies" />
      <div class="content">
        <h2>Canadian Rockies</h2>
        <p>Experience the breathtaking beauty of the Canadian Rockies with their majestic peaks and pristine wilderness.</p>
        <form action="../php_users_profile/favorite.php" method="POST">
          <input type="hidden" name="destination" value="Canadian Rockies">
          <button type="submit">❤️ Favorite</button>
        </form>
      </div>
    </div>
  
    <div class="card">
      <img src="../images/img_2.jpg" alt="Santorini, Greece" />
      <div class="content">
        <h2>Santorini, Greece</h2>
        <p>Marvel at the iconic white-washed buildings and vibrant blue domes overlooking the Aegean Sea.</p>
        <form action="../php_users_profile/favorite.php" method="POST">
          <input type="hidden" name="destination" value="Santorini, Greece">
          <button type="submit">❤️ Favorite</button>
        </form>
      </div>
    </div>
  
    <div class="card">
      <img src="../images/img_3.jpg" alt="Kyoto, Japan" />
      <div class="content">
        <h2>Kyoto, Japan</h2>
        <p>Immerse yourself in tradition and tranquility with ancient temples, tea houses, and cherry blossoms.</p>
        <form action="../php_users_profile/favorite.php" method="POST">
          <input type="hidden" name="destination" value="Kyoto, Japan">
          <button type="submit">❤️ Favorite</button>
        </form>
      </div>
    </div>
  
    <div class="card">
      <img src="../images/img_4.jpg" alt="Banff National Park" />
      <div class="content">
        <h2>Banff National Park</h2>
        <p>Explore turquoise lakes, snowy peaks, and forested valleys in Canada’s oldest national park.</p>
        <form action="../php_users_profile/favorite.php" method="POST">
          <input type="hidden" name="destination" value="Banff National Park">
          <button type="submit">❤️ Favorite</button>
        </form>
      </div>
    </div>
  
    <div class="card">
      <img src="../images/img_5.jpg" alt="Cape Town, South Africa" />
      <div class="content">
        <h2>Cape Town, South Africa</h2>
        <p>Take in panoramic views from Table Mountain and discover the beauty of South Africa’s coastline.</p>
        <form action="../php_users_profile/favorite.php" method="POST">
          <input type="hidden" name="destination" value="Cape Town, South Africa">
          <button type="submit">❤️ Favorite</button>
        </form>
      </div>
    </div>
  
    <div class="card">
      <img src="../images/img_6.jpg" />
      <div class="content">
        <h2>Petra, Jordan</h2>
        <p>Step into the past with a visit to the Rose City, a UNESCO World Heritage site carved into rock.</p>
        <form action="../php_users_profile/favorite.php" method="POST">
          <input type="hidden" name="destination" value="Petra, Jordan">
          <button type="submit">❤️ Favorite</button>
        </form>
      </div>
    </div>
  
    <div class="card">
      <img src="../images/img_7.jpg" alt="Maui, Hawaii" />
      <div class="content">
        <h2>Maui, Hawaii</h2>
        <p>Soak up the sun on golden beaches, explore lush rainforests, and witness stunning sunsets.</p>
        <form action="../php_users_profile/favorite.php" method="POST">
          <input type="hidden" name="destination" value="Maui, Hawaii">
          <button type="submit">❤️ Favorite</button>
        </form>
      </div>
    </div>
  
    <div class="card">
      <img src="../images/img_8.jpg" alt="Bali, Indonesia" />
      <div class="content">
        <h2>Bali, Indonesia</h2>
        <p>Find your bliss in a tropical paradise with rich culture, serene temples, and exotic beaches.</p>
        <form action="../php_users_profile/favorite.php" method="POST">
          <input type="hidden" name="destination" value="Bali, Indonesia">
          <button type="submit">❤️ Favorite</button>
        </form>
      </div>
    </div>
  
    <div class="card">
      <img src="../images/img_9.jpg" alt="Bohol, Philippines" />
      <div class="content">
        <h2>Bohol, Philippines</h2>
        <p>Experience the beautiful chocolate hills in bohol.</p>
        <form action="../php_users_profile/favorite.php" method="POST">
          <input type="hidden" name="destination" value="Bohol, Philippines">
          <button type="submit">❤️ Favorite</button>
        </form>
      </div>
    </div>
  
  </div>
</main>

<footer>
  <div class="container">
    <div>
      <h3>Tour Starter</h3>
      <p>Curating exceptional travel experiences since 2010.</p>
    </div>
    <div>
      <h3>Quick Links</h3>
      <ul>
        <li><a href="#">Home</a></li>
        <li><a href="#">Destinations</a></li>
        <li><a href="#">Travel Guides</a></li>
        <li><a href="#">About Us</a></li>
      </ul>
    </div>
    <div>
      <h3>Contact Us</h3>
      <p>Cagayan de Oro, Carmen, PHINMA COC</p>
      <p>+63 99199754558</p>
      <p>yocyocjoker@gmail.com</p>
    </div>
    <div>
      <h3>Newsletter</h3>
      <p>Subscribe for travel tips and offers.</p>
      <input type="email" placeholder="Your email">
      <button>Subscribe</button>
    </div>
  </div>
</footer>

</body>
</html>
