<?php session_start(); ?>
<?php
if (!isset($_SESSION["username"])) {
  header("Location: ../php_users_profile/login.php");
  exit;
}
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Contact Us</title>
    <link rel="stylesheet" href="../css/contact.css" />
    <link rel="stylesheet" href="../css/profile.css" />
    <link rel="stylesheet" href="../css/logo_php.css" />
    <link rel="icon" href="../images/logo_image_1.jpg" type="image/jpg">
  </head>
  <body>
    <header>
      <div class="container">
        <a href="home.html" class="logo"><img src="../images/logo_image_1.jpg" alt="Tour Starter Logo" class="logo-img">TOUR STARTER</a>
        <nav>
          <ul>
            <li><a href="home.php">Home</a></li>
            <li><a href="Gallery.php">Gallery</a></li>
            <li><a href="about.php">About</a></li>
            <li><a href="contact.php">Contact</a></li>
            <?php if (isset($_SESSION["username"])): ?>
            <li class="profile-img-li">
                <a href="../php_users_profile/profile.php" class="profile-link">
                    <img src="../profile_images/<?php echo $_SESSION['profile_image']; ?>" alt="User Profile Image" class="profile-img-corner">
                </a>
            </li>
          <?php endif; ?>
          </ul>
        </nav>
      </div>
    </header>

    <div class="main-content">
      <h1>Contact Us</h1>
      <p>
        Fill out the form and a member from our sales team will get back to you within 24 hours, or scroll down for more ways to get in touch.
      </p>

      <div class="contact-form-wrapper">
        <!-- Left Sidebar -->
        <div class="contact-info">
          <h2>Contact Tour Starter</h2>
          <p>Already a customer or need help with a billing issue? <a href="#">Contact Support</a></p>

          <h3>North America Sales</h3>
          <div class="contact-details">
            <i class="ri-phone-fill"></i>
            <a href="tel:+18007088749">+18007088749</a>
          </div>

          <h3>Luzon / Visayas / Mindanao</h3>
          <p>Fill out your details to be contacted.</p>

          <div class="social-icons">
            <a href="#"><i class="ri-facebook-fill"></i></a>
            <a href="#"><i class="ri-instagram-fill"></i></a>
          </div>
        </div>

        <!-- Right Form Section -->
        <div class="contact-form">
          <form>
            <label for="firstName">First Name</label>
            <input type="text" id="firstName" placeholder="First Name" />

            <label for="lastName">Last Name</label>
            <input type="text" id="lastName" placeholder="Last Name" />

            <label for="email">Email</label>
            <input type="email" id="email" placeholder="you@yoursite.com" />

            <label for="phone">Phone</label>
            <input type="tel" id="phone" placeholder="Phone" />

            <label for="company">Company Name</label>
            <input type="text" id="company" placeholder="Company Name" />

            <label for="industry">Industry</label>
            <select id="industry">
              <option value="" disabled selected>Select an Industry</option>
              <option value="technology">Technology</option>
              <option value="finance">Finance</option>
              <option value="healthcare">Healthcare</option>
              <option value="education">Education</option>
              <option value="retail">Retail</option>
            </select>

            <label for="revenue">Annual Revenue</label>
            <select id="revenue">
              <option value="" disabled selected>Select Revenue</option>
              <option value="less1m">Less than $1 million</option>
              <option value="1m-10m">$1 million - $10 million</option>
              <option value="10m-50m">$10 million - $50 million</option>
              <option value="50m-100m">$50 million - $100 million</option>
              <option value="more100m">More than $100 million</option>
            </select>

            <label for="country">Country</label>
            <select id="country">
              <option value="" disabled selected>Select a Country</option>
              <option value="us">United States</option>
              <option value="ca">Canada</option>
              <option value="uk">United Kingdom</option>
              <option value="au">Australia</option>
              <option value="de">Germany</option>
              <option value="fr">France</option>
              <option value="jp">Japan</option>
            </select>

            <div>
              <input type="checkbox" id="emailConsent" />
              <label for="emailConsent">Yes, I would like to receive news and offers from ACTIVE via email</label>
            </div>
            <div>
              <input type="checkbox" id="phoneConsent" />
              <label for="phoneConsent">Yes, I agree to receive phone calls from ACTIVE</label>
            </div>

            <button type="submit">Submit</button>
          </form>
        </div>
      </div>
    </div>
  </body>
</html>
